﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Water : MonoBehaviour {

    // This component is separate from the player's underwater movement.
    // Feel free to add whatever you want in here, like a rigidbody buoyancy/floating system or something.

}
